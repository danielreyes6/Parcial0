# Generated from Laplace.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .LaplaceParser import LaplaceParser
else:
    from LaplaceParser import LaplaceParser

# This class defines a complete listener for a parse tree produced by LaplaceParser.
class LaplaceListener(ParseTreeListener):

    # Enter a parse tree produced by LaplaceParser#program.
    def enterProgram(self, ctx:LaplaceParser.ProgramContext):
        pass

    # Exit a parse tree produced by LaplaceParser#program.
    def exitProgram(self, ctx:LaplaceParser.ProgramContext):
        pass


    # Enter a parse tree produced by LaplaceParser#expression.
    def enterExpression(self, ctx:LaplaceParser.ExpressionContext):
        pass

    # Exit a parse tree produced by LaplaceParser#expression.
    def exitExpression(self, ctx:LaplaceParser.ExpressionContext):
        pass


    # Enter a parse tree produced by LaplaceParser#function.
    def enterFunction(self, ctx:LaplaceParser.FunctionContext):
        pass

    # Exit a parse tree produced by LaplaceParser#function.
    def exitFunction(self, ctx:LaplaceParser.FunctionContext):
        pass


    # Enter a parse tree produced by LaplaceParser#constant.
    def enterConstant(self, ctx:LaplaceParser.ConstantContext):
        pass

    # Exit a parse tree produced by LaplaceParser#constant.
    def exitConstant(self, ctx:LaplaceParser.ConstantContext):
        pass


    # Enter a parse tree produced by LaplaceParser#exp_function.
    def enterExp_function(self, ctx:LaplaceParser.Exp_functionContext):
        pass

    # Exit a parse tree produced by LaplaceParser#exp_function.
    def exitExp_function(self, ctx:LaplaceParser.Exp_functionContext):
        pass


    # Enter a parse tree produced by LaplaceParser#time_function.
    def enterTime_function(self, ctx:LaplaceParser.Time_functionContext):
        pass

    # Exit a parse tree produced by LaplaceParser#time_function.
    def exitTime_function(self, ctx:LaplaceParser.Time_functionContext):
        pass



del LaplaceParser