# Generated from Laplace.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,8,34,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,1,0,1,0,
        1,0,1,1,1,1,1,1,1,1,1,1,1,2,1,2,1,2,3,2,24,8,2,1,3,1,3,1,4,1,4,1,
        4,1,4,1,5,1,5,1,5,0,0,6,0,2,4,6,8,10,0,0,29,0,12,1,0,0,0,2,15,1,
        0,0,0,4,23,1,0,0,0,6,25,1,0,0,0,8,27,1,0,0,0,10,31,1,0,0,0,12,13,
        3,2,1,0,13,14,5,0,0,1,14,1,1,0,0,0,15,16,5,1,0,0,16,17,5,2,0,0,17,
        18,3,4,2,0,18,19,5,3,0,0,19,3,1,0,0,0,20,24,3,6,3,0,21,24,3,8,4,
        0,22,24,3,10,5,0,23,20,1,0,0,0,23,21,1,0,0,0,23,22,1,0,0,0,24,5,
        1,0,0,0,25,26,5,4,0,0,26,7,1,0,0,0,27,28,5,5,0,0,28,29,5,7,0,0,29,
        30,5,6,0,0,30,9,1,0,0,0,31,32,5,6,0,0,32,11,1,0,0,0,1,23
    ]

class LaplaceParser ( Parser ):

    grammarFileName = "Laplace.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'Laplace'", "'('", "')'", "'1'", "'e^'", 
                     "'t'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "ID", "WS" ]

    RULE_program = 0
    RULE_expression = 1
    RULE_function = 2
    RULE_constant = 3
    RULE_exp_function = 4
    RULE_time_function = 5

    ruleNames =  [ "program", "expression", "function", "constant", "exp_function", 
                   "time_function" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    ID=7
    WS=8

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(LaplaceParser.ExpressionContext,0)


        def EOF(self):
            return self.getToken(LaplaceParser.EOF, 0)

        def getRuleIndex(self):
            return LaplaceParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)




    def program(self):

        localctx = LaplaceParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 12
            self.expression()
            self.state = 13
            self.match(LaplaceParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def function(self):
            return self.getTypedRuleContext(LaplaceParser.FunctionContext,0)


        def getRuleIndex(self):
            return LaplaceParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)




    def expression(self):

        localctx = LaplaceParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_expression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 15
            self.match(LaplaceParser.T__0)
            self.state = 16
            self.match(LaplaceParser.T__1)
            self.state = 17
            self.function()
            self.state = 18
            self.match(LaplaceParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def constant(self):
            return self.getTypedRuleContext(LaplaceParser.ConstantContext,0)


        def exp_function(self):
            return self.getTypedRuleContext(LaplaceParser.Exp_functionContext,0)


        def time_function(self):
            return self.getTypedRuleContext(LaplaceParser.Time_functionContext,0)


        def getRuleIndex(self):
            return LaplaceParser.RULE_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction" ):
                listener.enterFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction" ):
                listener.exitFunction(self)




    def function(self):

        localctx = LaplaceParser.FunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_function)
        try:
            self.state = 23
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [4]:
                self.enterOuterAlt(localctx, 1)
                self.state = 20
                self.constant()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)
                self.state = 21
                self.exp_function()
                pass
            elif token in [6]:
                self.enterOuterAlt(localctx, 3)
                self.state = 22
                self.time_function()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstantContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return LaplaceParser.RULE_constant

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstant" ):
                listener.enterConstant(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstant" ):
                listener.exitConstant(self)




    def constant(self):

        localctx = LaplaceParser.ConstantContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_constant)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 25
            self.match(LaplaceParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Exp_functionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(LaplaceParser.ID, 0)

        def getRuleIndex(self):
            return LaplaceParser.RULE_exp_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExp_function" ):
                listener.enterExp_function(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExp_function" ):
                listener.exitExp_function(self)




    def exp_function(self):

        localctx = LaplaceParser.Exp_functionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_exp_function)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 27
            self.match(LaplaceParser.T__4)
            self.state = 28
            self.match(LaplaceParser.ID)
            self.state = 29
            self.match(LaplaceParser.T__5)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Time_functionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return LaplaceParser.RULE_time_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTime_function" ):
                listener.enterTime_function(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTime_function" ):
                listener.exitTime_function(self)




    def time_function(self):

        localctx = LaplaceParser.Time_functionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_time_function)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 31
            self.match(LaplaceParser.T__5)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





