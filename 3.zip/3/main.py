from antlr4 import *
from LaplaceLexer import LaplaceLexer
from LaplaceParser import LaplaceParser

# Implementar las transformadas de Laplace manualmente para las funciones soportadas
def apply_laplace(function):
    if function == "1":
        return "1/s"
    elif function.startswith("e^"):
        a = function[2]  # Extraer el valor de 'a' en e^(at)
        return f"1/(s - {a})"
    elif function == "t":
        return "1/s^2"
    else:
        return "Función no soportada"

# Interpretar el árbol de análisis para aplicar la transformada
def interpret_laplace(tree):
    # Acceder al nodo de la función
    function = tree.getChild(0).getChild(2).getText()  # Acceso directo al nodo de la función
    return apply_laplace(function)

def main():
    # Leer las expresiones desde un archivo input.txt
    with open("input.txt", "r") as file:
        lines = file.readlines()

    for line in lines:
        line = line.strip()  # Eliminar espacios en blanco y saltos de línea

        if line:  # Si la línea no está vacía
            input_stream = InputStream(line)
            
            # Crear el lexer y el parser
            lexer = LaplaceLexer(input_stream)
            token_stream = CommonTokenStream(lexer)
            parser = LaplaceParser(token_stream)

            # Parsear el programa
            tree = parser.program()

            # Interpretar y aplicar la transformada de Laplace
            result = interpret_laplace(tree)
            print(f"Expresión: {line}, Transformada: {result}")

if __name__ == '__main__':
    main()

