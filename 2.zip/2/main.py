from antlr4 import *
from MapFunctionLexer import MapFunctionLexer
from MapFunctionParser import MapFunctionParser

# Implementación de las operaciones MAP y FILTER
def apply_map(function, iterable):
    return [function(x) for x in iterable]

def apply_filter(condition, iterable):
    return [x for x in iterable if condition(x)]

from antlr4 import *
from MapFunctionLexer import MapFunctionLexer
from MapFunctionParser import MapFunctionParser

# Implementación de las operaciones MAP y FILTER
def apply_map(function, iterable):
    return [function(x) for x in iterable]

def apply_filter(condition, iterable):
    return [x for x in iterable if condition(x)]

# Función para ejecutar MAP o FILTER basados en la entrada
def execute_expression(expression):
    if isinstance(expression, tuple) and expression[0] == 'MAP':
        # Ejecutar MAP
        function = expression[1]
        iterable = expression[2]
        result = apply_map(function, iterable)
        print("Resultado MAP:", result)
    elif isinstance(expression, tuple) and expression[0] == 'FILTER':
        # Ejecutar FILTER
        condition = expression[1]
        iterable = expression[2]
        result = apply_filter(condition, iterable)
        print("Resultado FILTER:", result)

# Función para interpretar las funciones MAP/FILTER parseadas
def interpret_map_filter(tree):
    # Simulación simple para demostrar la ejecución de MAP y FILTER
    if 'MAP' in tree:
        return ('MAP', lambda x: x + 1, [1, 2, 3])
    elif 'FILTER' in tree:
        return ('FILTER', lambda x: x % 2 == 0, [1, 2, 3, 4])

# Función principal que lee desde un archivo
def main():
    # Leer las expresiones desde el archivo input.txt
    with open("input.txt", "r") as file:
        lines = file.readlines()

    for line in lines:
        line = line.strip()  # Eliminar espacios en blanco y saltos de línea

        if line:  # Si la línea no está vacía
            input_stream = InputStream(line)
            
            # Crear el lexer y el parser
            lexer = MapFunctionLexer(input_stream)
            token_stream = CommonTokenStream(lexer)
            parser = MapFunctionParser(token_stream)

            # Parsear el programa
            tree = parser.program()

            # Simular la ejecución (esto se haría según el análisis del árbol de parseo)
            expression = interpret_map_filter(line)

            # Ejecutar la operación correspondiente (MAP o FILTER)
            execute_expression(expression)

if __name__ == '__main__':
    main()

