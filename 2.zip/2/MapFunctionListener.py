# Generated from MapFunction.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .MapFunctionParser import MapFunctionParser
else:
    from MapFunctionParser import MapFunctionParser

# This class defines a complete listener for a parse tree produced by MapFunctionParser.
class MapFunctionListener(ParseTreeListener):

    # Enter a parse tree produced by MapFunctionParser#program.
    def enterProgram(self, ctx:MapFunctionParser.ProgramContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#program.
    def exitProgram(self, ctx:MapFunctionParser.ProgramContext):
        pass


    # Enter a parse tree produced by MapFunctionParser#expression.
    def enterExpression(self, ctx:MapFunctionParser.ExpressionContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#expression.
    def exitExpression(self, ctx:MapFunctionParser.ExpressionContext):
        pass


    # Enter a parse tree produced by MapFunctionParser#mapFunction.
    def enterMapFunction(self, ctx:MapFunctionParser.MapFunctionContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#mapFunction.
    def exitMapFunction(self, ctx:MapFunctionParser.MapFunctionContext):
        pass


    # Enter a parse tree produced by MapFunctionParser#filterFunction.
    def enterFilterFunction(self, ctx:MapFunctionParser.FilterFunctionContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#filterFunction.
    def exitFilterFunction(self, ctx:MapFunctionParser.FilterFunctionContext):
        pass


    # Enter a parse tree produced by MapFunctionParser#lambda.
    def enterLambda(self, ctx:MapFunctionParser.LambdaContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#lambda.
    def exitLambda(self, ctx:MapFunctionParser.LambdaContext):
        pass


    # Enter a parse tree produced by MapFunctionParser#expressionBody.
    def enterExpressionBody(self, ctx:MapFunctionParser.ExpressionBodyContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#expressionBody.
    def exitExpressionBody(self, ctx:MapFunctionParser.ExpressionBodyContext):
        pass


    # Enter a parse tree produced by MapFunctionParser#expressionBinary.
    def enterExpressionBinary(self, ctx:MapFunctionParser.ExpressionBinaryContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#expressionBinary.
    def exitExpressionBinary(self, ctx:MapFunctionParser.ExpressionBinaryContext):
        pass


    # Enter a parse tree produced by MapFunctionParser#operator.
    def enterOperator(self, ctx:MapFunctionParser.OperatorContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#operator.
    def exitOperator(self, ctx:MapFunctionParser.OperatorContext):
        pass


    # Enter a parse tree produced by MapFunctionParser#comparisonOperator.
    def enterComparisonOperator(self, ctx:MapFunctionParser.ComparisonOperatorContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#comparisonOperator.
    def exitComparisonOperator(self, ctx:MapFunctionParser.ComparisonOperatorContext):
        pass


    # Enter a parse tree produced by MapFunctionParser#iterable.
    def enterIterable(self, ctx:MapFunctionParser.IterableContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#iterable.
    def exitIterable(self, ctx:MapFunctionParser.IterableContext):
        pass


    # Enter a parse tree produced by MapFunctionParser#list.
    def enterList(self, ctx:MapFunctionParser.ListContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#list.
    def exitList(self, ctx:MapFunctionParser.ListContext):
        pass


    # Enter a parse tree produced by MapFunctionParser#param.
    def enterParam(self, ctx:MapFunctionParser.ParamContext):
        pass

    # Exit a parse tree produced by MapFunctionParser#param.
    def exitParam(self, ctx:MapFunctionParser.ParamContext):
        pass



del MapFunctionParser