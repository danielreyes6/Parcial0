# Generated from MapFunction.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,18,97,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,1,0,5,0,26,8,0,10,
        0,12,0,29,9,0,1,0,1,0,1,1,1,1,3,1,35,8,1,1,2,1,2,1,2,1,2,1,2,1,2,
        1,2,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,4,1,4,1,4,1,4,1,4,1,5,1,5,3,5,
        58,8,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,5,6,71,8,6,10,
        6,12,6,74,9,6,1,7,1,7,1,8,1,8,1,9,1,9,1,10,1,10,1,10,1,10,5,10,86,
        8,10,10,10,12,10,89,9,10,3,10,91,8,10,1,10,1,10,1,11,1,11,1,11,0,
        1,12,12,0,2,4,6,8,10,12,14,16,18,20,22,0,2,1,0,8,12,1,0,4,5,91,0,
        27,1,0,0,0,2,34,1,0,0,0,4,36,1,0,0,0,6,43,1,0,0,0,8,50,1,0,0,0,10,
        57,1,0,0,0,12,59,1,0,0,0,14,75,1,0,0,0,16,77,1,0,0,0,18,79,1,0,0,
        0,20,81,1,0,0,0,22,94,1,0,0,0,24,26,3,2,1,0,25,24,1,0,0,0,26,29,
        1,0,0,0,27,25,1,0,0,0,27,28,1,0,0,0,28,30,1,0,0,0,29,27,1,0,0,0,
        30,31,5,0,0,1,31,1,1,0,0,0,32,35,3,4,2,0,33,35,3,6,3,0,34,32,1,0,
        0,0,34,33,1,0,0,0,35,3,1,0,0,0,36,37,5,1,0,0,37,38,5,13,0,0,38,39,
        3,8,4,0,39,40,5,17,0,0,40,41,3,18,9,0,41,42,5,14,0,0,42,5,1,0,0,
        0,43,44,5,2,0,0,44,45,5,13,0,0,45,46,3,8,4,0,46,47,5,17,0,0,47,48,
        3,18,9,0,48,49,5,14,0,0,49,7,1,0,0,0,50,51,5,3,0,0,51,52,5,4,0,0,
        52,53,5,6,0,0,53,54,3,10,5,0,54,9,1,0,0,0,55,58,3,12,6,0,56,58,3,
        22,11,0,57,55,1,0,0,0,57,56,1,0,0,0,58,11,1,0,0,0,59,60,6,6,-1,0,
        60,61,3,22,11,0,61,72,1,0,0,0,62,63,10,3,0,0,63,64,3,14,7,0,64,65,
        3,12,6,4,65,71,1,0,0,0,66,67,10,2,0,0,67,68,3,16,8,0,68,69,3,12,
        6,3,69,71,1,0,0,0,70,62,1,0,0,0,70,66,1,0,0,0,71,74,1,0,0,0,72,70,
        1,0,0,0,72,73,1,0,0,0,73,13,1,0,0,0,74,72,1,0,0,0,75,76,7,0,0,0,
        76,15,1,0,0,0,77,78,5,7,0,0,78,17,1,0,0,0,79,80,3,20,10,0,80,19,
        1,0,0,0,81,90,5,15,0,0,82,87,3,22,11,0,83,84,5,17,0,0,84,86,3,22,
        11,0,85,83,1,0,0,0,86,89,1,0,0,0,87,85,1,0,0,0,87,88,1,0,0,0,88,
        91,1,0,0,0,89,87,1,0,0,0,90,82,1,0,0,0,90,91,1,0,0,0,91,92,1,0,0,
        0,92,93,5,16,0,0,93,21,1,0,0,0,94,95,7,1,0,0,95,23,1,0,0,0,7,27,
        34,57,70,72,87,90
    ]

class MapFunctionParser ( Parser ):

    grammarFileName = "MapFunction.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'MAP'", "'FILTER'", "'lambda'", "<INVALID>", 
                     "<INVALID>", "':'", "'=='", "'+'", "'-'", "'*'", "'/'", 
                     "'%'", "'('", "')'", "'['", "']'", "','" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "ID", "NUMBER", "COLON", "EQ", "PLUS", "MINUS", "MULT", 
                      "DIV", "MOD", "LPAREN", "RPAREN", "LBRACK", "RBRACK", 
                      "COMMA", "WS" ]

    RULE_program = 0
    RULE_expression = 1
    RULE_mapFunction = 2
    RULE_filterFunction = 3
    RULE_lambda = 4
    RULE_expressionBody = 5
    RULE_expressionBinary = 6
    RULE_operator = 7
    RULE_comparisonOperator = 8
    RULE_iterable = 9
    RULE_list = 10
    RULE_param = 11

    ruleNames =  [ "program", "expression", "mapFunction", "filterFunction", 
                   "lambda", "expressionBody", "expressionBinary", "operator", 
                   "comparisonOperator", "iterable", "list", "param" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    ID=4
    NUMBER=5
    COLON=6
    EQ=7
    PLUS=8
    MINUS=9
    MULT=10
    DIV=11
    MOD=12
    LPAREN=13
    RPAREN=14
    LBRACK=15
    RBRACK=16
    COMMA=17
    WS=18

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(MapFunctionParser.EOF, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapFunctionParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(MapFunctionParser.ExpressionContext,i)


        def getRuleIndex(self):
            return MapFunctionParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)




    def program(self):

        localctx = MapFunctionParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 27
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1 or _la==2:
                self.state = 24
                self.expression()
                self.state = 29
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 30
            self.match(MapFunctionParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapFunction(self):
            return self.getTypedRuleContext(MapFunctionParser.MapFunctionContext,0)


        def filterFunction(self):
            return self.getTypedRuleContext(MapFunctionParser.FilterFunctionContext,0)


        def getRuleIndex(self):
            return MapFunctionParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)




    def expression(self):

        localctx = MapFunctionParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_expression)
        try:
            self.state = 34
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1]:
                self.enterOuterAlt(localctx, 1)
                self.state = 32
                self.mapFunction()
                pass
            elif token in [2]:
                self.enterOuterAlt(localctx, 2)
                self.state = 33
                self.filterFunction()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapFunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(MapFunctionParser.LPAREN, 0)

        def lambda_(self):
            return self.getTypedRuleContext(MapFunctionParser.LambdaContext,0)


        def COMMA(self):
            return self.getToken(MapFunctionParser.COMMA, 0)

        def iterable(self):
            return self.getTypedRuleContext(MapFunctionParser.IterableContext,0)


        def RPAREN(self):
            return self.getToken(MapFunctionParser.RPAREN, 0)

        def getRuleIndex(self):
            return MapFunctionParser.RULE_mapFunction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapFunction" ):
                listener.enterMapFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapFunction" ):
                listener.exitMapFunction(self)




    def mapFunction(self):

        localctx = MapFunctionParser.MapFunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_mapFunction)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 36
            self.match(MapFunctionParser.T__0)
            self.state = 37
            self.match(MapFunctionParser.LPAREN)
            self.state = 38
            self.lambda_()
            self.state = 39
            self.match(MapFunctionParser.COMMA)
            self.state = 40
            self.iterable()
            self.state = 41
            self.match(MapFunctionParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FilterFunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(MapFunctionParser.LPAREN, 0)

        def lambda_(self):
            return self.getTypedRuleContext(MapFunctionParser.LambdaContext,0)


        def COMMA(self):
            return self.getToken(MapFunctionParser.COMMA, 0)

        def iterable(self):
            return self.getTypedRuleContext(MapFunctionParser.IterableContext,0)


        def RPAREN(self):
            return self.getToken(MapFunctionParser.RPAREN, 0)

        def getRuleIndex(self):
            return MapFunctionParser.RULE_filterFunction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFilterFunction" ):
                listener.enterFilterFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFilterFunction" ):
                listener.exitFilterFunction(self)




    def filterFunction(self):

        localctx = MapFunctionParser.FilterFunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_filterFunction)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 43
            self.match(MapFunctionParser.T__1)
            self.state = 44
            self.match(MapFunctionParser.LPAREN)
            self.state = 45
            self.lambda_()
            self.state = 46
            self.match(MapFunctionParser.COMMA)
            self.state = 47
            self.iterable()
            self.state = 48
            self.match(MapFunctionParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LambdaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(MapFunctionParser.ID, 0)

        def COLON(self):
            return self.getToken(MapFunctionParser.COLON, 0)

        def expressionBody(self):
            return self.getTypedRuleContext(MapFunctionParser.ExpressionBodyContext,0)


        def getRuleIndex(self):
            return MapFunctionParser.RULE_lambda

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLambda" ):
                listener.enterLambda(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLambda" ):
                listener.exitLambda(self)




    def lambda_(self):

        localctx = MapFunctionParser.LambdaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_lambda)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 50
            self.match(MapFunctionParser.T__2)
            self.state = 51
            self.match(MapFunctionParser.ID)
            self.state = 52
            self.match(MapFunctionParser.COLON)
            self.state = 53
            self.expressionBody()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionBodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expressionBinary(self):
            return self.getTypedRuleContext(MapFunctionParser.ExpressionBinaryContext,0)


        def param(self):
            return self.getTypedRuleContext(MapFunctionParser.ParamContext,0)


        def getRuleIndex(self):
            return MapFunctionParser.RULE_expressionBody

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpressionBody" ):
                listener.enterExpressionBody(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpressionBody" ):
                listener.exitExpressionBody(self)




    def expressionBody(self):

        localctx = MapFunctionParser.ExpressionBodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_expressionBody)
        try:
            self.state = 57
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 55
                self.expressionBinary(0)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 56
                self.param()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionBinaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def param(self):
            return self.getTypedRuleContext(MapFunctionParser.ParamContext,0)


        def expressionBinary(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapFunctionParser.ExpressionBinaryContext)
            else:
                return self.getTypedRuleContext(MapFunctionParser.ExpressionBinaryContext,i)


        def operator(self):
            return self.getTypedRuleContext(MapFunctionParser.OperatorContext,0)


        def comparisonOperator(self):
            return self.getTypedRuleContext(MapFunctionParser.ComparisonOperatorContext,0)


        def getRuleIndex(self):
            return MapFunctionParser.RULE_expressionBinary

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpressionBinary" ):
                listener.enterExpressionBinary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpressionBinary" ):
                listener.exitExpressionBinary(self)



    def expressionBinary(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = MapFunctionParser.ExpressionBinaryContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 12
        self.enterRecursionRule(localctx, 12, self.RULE_expressionBinary, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 60
            self.param()
            self._ctx.stop = self._input.LT(-1)
            self.state = 72
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 70
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
                    if la_ == 1:
                        localctx = MapFunctionParser.ExpressionBinaryContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expressionBinary)
                        self.state = 62
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 63
                        self.operator()
                        self.state = 64
                        self.expressionBinary(4)
                        pass

                    elif la_ == 2:
                        localctx = MapFunctionParser.ExpressionBinaryContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expressionBinary)
                        self.state = 66
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 67
                        self.comparisonOperator()
                        self.state = 68
                        self.expressionBinary(3)
                        pass

             
                self.state = 74
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class OperatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PLUS(self):
            return self.getToken(MapFunctionParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(MapFunctionParser.MINUS, 0)

        def MULT(self):
            return self.getToken(MapFunctionParser.MULT, 0)

        def DIV(self):
            return self.getToken(MapFunctionParser.DIV, 0)

        def MOD(self):
            return self.getToken(MapFunctionParser.MOD, 0)

        def getRuleIndex(self):
            return MapFunctionParser.RULE_operator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperator" ):
                listener.enterOperator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperator" ):
                listener.exitOperator(self)




    def operator(self):

        localctx = MapFunctionParser.OperatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_operator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 75
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 7936) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparisonOperatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EQ(self):
            return self.getToken(MapFunctionParser.EQ, 0)

        def getRuleIndex(self):
            return MapFunctionParser.RULE_comparisonOperator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparisonOperator" ):
                listener.enterComparisonOperator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparisonOperator" ):
                listener.exitComparisonOperator(self)




    def comparisonOperator(self):

        localctx = MapFunctionParser.ComparisonOperatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_comparisonOperator)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 77
            self.match(MapFunctionParser.EQ)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IterableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def list_(self):
            return self.getTypedRuleContext(MapFunctionParser.ListContext,0)


        def getRuleIndex(self):
            return MapFunctionParser.RULE_iterable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIterable" ):
                listener.enterIterable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIterable" ):
                listener.exitIterable(self)




    def iterable(self):

        localctx = MapFunctionParser.IterableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_iterable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 79
            self.list_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACK(self):
            return self.getToken(MapFunctionParser.LBRACK, 0)

        def RBRACK(self):
            return self.getToken(MapFunctionParser.RBRACK, 0)

        def param(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapFunctionParser.ParamContext)
            else:
                return self.getTypedRuleContext(MapFunctionParser.ParamContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(MapFunctionParser.COMMA)
            else:
                return self.getToken(MapFunctionParser.COMMA, i)

        def getRuleIndex(self):
            return MapFunctionParser.RULE_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterList" ):
                listener.enterList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitList" ):
                listener.exitList(self)




    def list_(self):

        localctx = MapFunctionParser.ListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 81
            self.match(MapFunctionParser.LBRACK)
            self.state = 90
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==4 or _la==5:
                self.state = 82
                self.param()
                self.state = 87
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==17:
                    self.state = 83
                    self.match(MapFunctionParser.COMMA)
                    self.state = 84
                    self.param()
                    self.state = 89
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 92
            self.match(MapFunctionParser.RBRACK)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(MapFunctionParser.ID, 0)

        def NUMBER(self):
            return self.getToken(MapFunctionParser.NUMBER, 0)

        def getRuleIndex(self):
            return MapFunctionParser.RULE_param

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParam" ):
                listener.enterParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParam" ):
                listener.exitParam(self)




    def param(self):

        localctx = MapFunctionParser.ParamContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_param)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 94
            _la = self._input.LA(1)
            if not(_la==4 or _la==5):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[6] = self.expressionBinary_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expressionBinary_sempred(self, localctx:ExpressionBinaryContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 2)
         




