import sys
from antlr4 import *
from RationalOperationsLexer import RationalOperationsLexer
from RationalOperationsParser import RationalOperationsParser
from RationalVisitor import EvalVisitor

def main():
    input_stream = InputStream(input("Ingresa una expresión: "))
    lexer = RationalOperationsLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = RationalOperationsParser(stream)
    tree = parser.expr()

    visitor = EvalVisitor()
    result = visitor.visit(tree)
    
    if result is not None:
        # Solo imprime el resultado en formato de fracción
        print(f"{result[0]}/{result[1]}")
    else:
        print("Error: No se pudo calcular el resultado.")

if __name__ == '__main__':
    main()



