# Generated from RationalOperations.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .RationalOperationsParser import RationalOperationsParser
else:
    from RationalOperationsParser import RationalOperationsParser

# This class defines a complete listener for a parse tree produced by RationalOperationsParser.
class RationalOperationsListener(ParseTreeListener):

    # Enter a parse tree produced by RationalOperationsParser#RationalExpr.
    def enterRationalExpr(self, ctx:RationalOperationsParser.RationalExprContext):
        pass

    # Exit a parse tree produced by RationalOperationsParser#RationalExpr.
    def exitRationalExpr(self, ctx:RationalOperationsParser.RationalExprContext):
        pass


    # Enter a parse tree produced by RationalOperationsParser#AddSub.
    def enterAddSub(self, ctx:RationalOperationsParser.AddSubContext):
        pass

    # Exit a parse tree produced by RationalOperationsParser#AddSub.
    def exitAddSub(self, ctx:RationalOperationsParser.AddSubContext):
        pass


    # Enter a parse tree produced by RationalOperationsParser#MulDiv.
    def enterMulDiv(self, ctx:RationalOperationsParser.MulDivContext):
        pass

    # Exit a parse tree produced by RationalOperationsParser#MulDiv.
    def exitMulDiv(self, ctx:RationalOperationsParser.MulDivContext):
        pass


    # Enter a parse tree produced by RationalOperationsParser#Parens.
    def enterParens(self, ctx:RationalOperationsParser.ParensContext):
        pass

    # Exit a parse tree produced by RationalOperationsParser#Parens.
    def exitParens(self, ctx:RationalOperationsParser.ParensContext):
        pass


    # Enter a parse tree produced by RationalOperationsParser#Fraction.
    def enterFraction(self, ctx:RationalOperationsParser.FractionContext):
        pass

    # Exit a parse tree produced by RationalOperationsParser#Fraction.
    def exitFraction(self, ctx:RationalOperationsParser.FractionContext):
        pass


    # Enter a parse tree produced by RationalOperationsParser#Integer.
    def enterInteger(self, ctx:RationalOperationsParser.IntegerContext):
        pass

    # Exit a parse tree produced by RationalOperationsParser#Integer.
    def exitInteger(self, ctx:RationalOperationsParser.IntegerContext):
        pass



del RationalOperationsParser