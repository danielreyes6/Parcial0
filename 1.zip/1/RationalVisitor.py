from RationalOperationsParser import RationalOperationsParser
from RationalOperationsVisitor import RationalOperationsVisitor

class EvalVisitor(RationalOperationsVisitor):

    def visitAddSub(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        if left is None or right is None:
            return None  # Si alguna subexpresión no devuelve nada, error.
        
        if ctx.getChild(1).getText() == '+':
            # Suma cruzada de fracciones
            result = (left[0] * right[1] + right[0] * left[1], left[1] * right[1])
        else:
            # Resta cruzada de fracciones
            result = (left[0] * right[1] - right[0] * left[1], left[1] * right[1])
        
        return self.simplify(result)

    def visitMulDiv(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        if left is None or right is None:
            return None  # Si alguna subexpresión no devuelve nada, error.
        
        # Si hay división por 0, marca operación inválida
        if right[0] == 0 or right[1] == 0:
            print("Operación inválida: división por 0.")
            return None
        
        if ctx.getChild(1).getText() == '*':
            result = (left[0] * right[0], left[1] * right[1])  # Multiplicación de fracciones
        else:
            result = (left[0] * right[1], left[1] * right[0])  # División de fracciones
        
        return self.simplify(result)

    def visitParens(self, ctx):
        # Evalúa la expresión entre paréntesis
        return self.visit(ctx.expr())

    def visitFraction(self, ctx):
        numerator = int(ctx.INT(0).getText())
        denominator = int(ctx.INT(1).getText())
        
        # Si el denominador es 0, marca operación inválida
        if denominator == 0:
            print("Operación inválida: denominador es 0.")
            return (1, 0)
        
        return (numerator, denominator)

    def visitInteger(self, ctx):
        value = int(ctx.INT().getText())
        return (value, 1)

    def simplify(self, fraction):
        """ Simplifica una fracción (numerador, denominador) usando el MCD y devuelve 0 si el numerador es 0. """
        num, denom = fraction
        
        # Si el numerador es 0, devolver 0
        if num == 0 or denom == 0:
            return (0, 0)
        
        # Si numerador y denominador son iguales, devolver 1/1
        if num == denom:
            return (1,1)
        
        # De lo contrario, simplificar usando el MCD
        from math import gcd
        divisor = gcd(num, denom)
        return (num // divisor, denom // divisor)

