# Generated from RationalOperations.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .RationalOperationsParser import RationalOperationsParser
else:
    from RationalOperationsParser import RationalOperationsParser

# This class defines a complete generic visitor for a parse tree produced by RationalOperationsParser.

class RationalOperationsVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by RationalOperationsParser#RationalExpr.
    def visitRationalExpr(self, ctx:RationalOperationsParser.RationalExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RationalOperationsParser#AddSub.
    def visitAddSub(self, ctx:RationalOperationsParser.AddSubContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RationalOperationsParser#MulDiv.
    def visitMulDiv(self, ctx:RationalOperationsParser.MulDivContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RationalOperationsParser#Parens.
    def visitParens(self, ctx:RationalOperationsParser.ParensContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RationalOperationsParser#Fraction.
    def visitFraction(self, ctx:RationalOperationsParser.FractionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RationalOperationsParser#Integer.
    def visitInteger(self, ctx:RationalOperationsParser.IntegerContext):
        return self.visitChildren(ctx)



del RationalOperationsParser